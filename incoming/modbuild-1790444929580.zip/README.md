# TNT x1000 (Fabric, Minecraft 1.21.11)

Добавляет блок **Mega TNT** — ведёт себя как обычный ТНТ (поджигается
кремнём и сталью, огнём, редстоуном), но взрывается **в 1000 раз
сильнее** (сила взрыва 4000 вместо 4).

## Сборка

1. Установи JDK 21.
2. В папке проекта: `./gradlew build` (Linux/macOS) или `gradlew.bat build` (Windows).
   Gradle Wrapper скачается сам при первом запуске, если у тебя есть интернет
   и установлен Gradle ≥8, либо запусти `gradle wrapper` один раз вручную.
3. Готовый .jar появится в `build/libs/tnt1000-1.0.0.jar`.
4. Положи файл в папку `mods` клиента/сервера Fabric (нужен также
   установленный **Fabric API** для этой версии игры).

## Как это работает

- `MegaTntBlock` — обычный `TntBlock`, никакой особой логики.
- Mixin `TntBlockMixin` перехватывает `TntBlock.primeTnt(...)` и, если
  поджигается именно `MegaTntBlock`, спавнит `MegaTntEntity` вместо
  ванильного `TntEntity`.
- `MegaTntEntity.explode()` вызывает взрыв с силой `4.0 * 1000`.

## Если сборка не проходит

Minecraft-моддинг API меняется от версии к версии. Если Gradle не найдёт
`fabric_version` / `loader_version` из `gradle.properties`, зайди на
https://fabricmc.net/develop/ , выбери версию игры **1.21.11** и подставь
актуальные номера Fabric Loader и Fabric API.
