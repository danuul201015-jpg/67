package com.qaz10.tnt1000.client;

import com.qaz10.tnt1000.Tnt1000Mod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.TntEntityRenderer;

public class Tnt1000ModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Переиспользуем ванильный рендерер примированного ТНТ —
		// он рисует блок как летающую сущность, текстура берётся из блока.
		EntityRendererRegistry.register(Tnt1000Mod.MEGA_TNT_ENTITY, TntEntityRenderer::new);
	}
}
