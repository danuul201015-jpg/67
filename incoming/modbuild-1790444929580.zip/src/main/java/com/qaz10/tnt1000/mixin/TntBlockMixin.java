package com.qaz10.tnt1000.mixin;

import com.qaz10.tnt1000.block.MegaTntBlock;
import com.qaz10.tnt1000.entity.MegaTntEntity;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import javax.annotation.Nullable;

/**
 * Перехватывает TntBlock.primeTnt(...) (в Yarn 1.21.11 оба метода
 * возвращают boolean) и, если поджигаемый блок — MegaTntBlock,
 * спавнит MegaTntEntity вместо обычного TntEntity.
 */
@Mixin(TntBlock.class)
public class TntBlockMixin {

	@Inject(
			method = "primeTnt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/LivingEntity;)Z",
			at = @At("HEAD"),
			cancellable = true
	)
	private static void tnt1000$primeMegaTnt(World world, BlockPos pos, @Nullable LivingEntity igniter,
			CallbackInfoReturnable<Boolean> cir) {
		if (!(world.getBlockState(pos).getBlock() instanceof MegaTntBlock)) {
			return;
		}
		if (!world.isClient) {
			MegaTntEntity entity = MegaTntEntity.create(
					world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, igniter);
			world.spawnEntity(entity);
			world.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
					SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
			world.emitGameEvent(igniter, GameEvent.PRIME_FUSE, pos);
		}
		cir.setReturnValue(true);
	}

	@Inject(
			method = "primeTnt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z",
			at = @At("HEAD"),
			cancellable = true
	)
	private static void tnt1000$primeMegaTntNoIgniter(World world, BlockPos pos,
			CallbackInfoReturnable<Boolean> cir) {
		tnt1000$primeMegaTnt(world, pos, null, cir);
	}
}
