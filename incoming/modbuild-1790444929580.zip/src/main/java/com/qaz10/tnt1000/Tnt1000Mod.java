package com.qaz10.tnt1000;

import com.qaz10.tnt1000.block.MegaTntBlock;
import com.qaz10.tnt1000.entity.MegaTntEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Tnt1000Mod implements ModInitializer {

	public static final String MOD_ID = "tnt1000";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Множитель мощности взрыва относительно обычного ТНТ (сила ТНТ по умолчанию = 4.0). */
	public static final float POWER_MULTIPLIER = 1000.0F;

	public static final Block MEGA_TNT_BLOCK = new MegaTntBlock(
			AbstractBlock.Settings.create()
					.mapColor(MapColor.RED)
					.sounds(BlockSoundGroup.GRASS)
					.breakInstantly()
	);

	public static final Item MEGA_TNT_ITEM = new BlockItem(MEGA_TNT_BLOCK, new Item.Settings());

	public static final RegistryKey<EntityType<?>> MEGA_TNT_ENTITY_KEY =
			RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(MOD_ID, "mega_tnt"));

	public static final EntityType<MegaTntEntity> MEGA_TNT_ENTITY = EntityType.Builder
			.<MegaTntEntity>create(MegaTntEntity::new, SpawnGroup.MISC)
			.dimensions(0.98F, 0.98F)
			.maxTrackingRange(10)
			.trackingTickInterval(10)
			.build(MEGA_TNT_ENTITY_KEY);

	@Override
	public void onInitialize() {
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "mega_tnt"), MEGA_TNT_BLOCK);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "mega_tnt"), MEGA_TNT_ITEM);
		Registry.register(Registries.ENTITY_TYPE, MEGA_TNT_ENTITY_KEY, MEGA_TNT_ENTITY);

		ItemGroupEvents.modifyEntriesEvent(ItemGroups.REDSTONE).register(entries -> entries.add(MEGA_TNT_ITEM));

		LOGGER.info("[tnt1000] Mega TNT (x{}) зарегистрирован", (int) POWER_MULTIPLIER);
	}
}
