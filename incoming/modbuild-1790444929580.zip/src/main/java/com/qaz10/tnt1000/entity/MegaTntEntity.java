package com.qaz10.tnt1000.entity;

import com.qaz10.tnt1000.Tnt1000Mod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Обычная механика примированного ТНТ (полёт, фитиль, отрисовка),
 * но сила взрыва увеличена в {@link Tnt1000Mod#POWER_MULTIPLIER} раз.
 */
public class MegaTntEntity extends TntEntity {

	/** Базовая сила взрыва ванильного ТНТ = 4.0F. */
	private static final float BASE_TNT_POWER = 4.0F;
	public static final float EXPLOSION_POWER = BASE_TNT_POWER * Tnt1000Mod.POWER_MULTIPLIER;

	// Требуется фабрике EntityType.
	public MegaTntEntity(EntityType<? extends TntEntity> type, World world) {
		super(type, world);
	}

	/** Спавнит примированный МегаТНТ так же, как это делает TntBlock#primeTnt. */
	public static MegaTntEntity create(World world, double x, double y, double z, @Nullable LivingEntity igniter) {
		MegaTntEntity entity = new MegaTntEntity(Tnt1000Mod.MEGA_TNT_ENTITY, world);
		entity.setPosition(x, y, z);
		double angle = world.getRandom().nextDouble() * (Math.PI * 2.0);
		entity.setVelocity(-Math.sin(angle) * 0.02, 0.2, -Math.cos(angle) * 0.02);
		entity.setFuse(80);
		return entity;
	}

	@Override
	protected void explode() {
		Vec3d pos = this.getPos();
		this.getWorld().createExplosion(
				this,
				pos.x, pos.y, pos.z,
				EXPLOSION_POWER,
				false,
				World.ExplosionSourceType.TNT
		);
	}
}
