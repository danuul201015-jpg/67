package com.qaz10.tnt1000.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.TntBlock;

/**
 * Ведёт себя как обычный TntBlock (поджигается кремнём и сталью, огнём,
 * редстоуном), но {@link com.qaz10.tnt1000.mixin.TntBlockMixin} подменяет
 * заспавненную сущность на {@link com.qaz10.tnt1000.entity.MegaTntEntity},
 * у которой сила взрыва умножена в 1000 раз.
 */
public class MegaTntBlock extends TntBlock {
	public MegaTntBlock(AbstractBlock.Settings settings) {
		super(settings);
	}
}
