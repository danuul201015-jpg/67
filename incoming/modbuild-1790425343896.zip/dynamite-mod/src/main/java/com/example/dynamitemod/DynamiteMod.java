package com.example.dynamitemod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DynamiteMod implements ModInitializer {
    public static final String MOD_ID = "dynamitemod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Dynamite Mod loaded — go blow something up.");
        ModItems.registerModItems();
    }
}
