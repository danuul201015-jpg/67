package com.example.dynamitemod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    // Blast power roughly compared to vanilla TNT (power 4.0):
    //  x1  -> about as strong as normal TNT
    //  x5  -> a serious crater
    //  x10 -> flattens a small hill; use away from your base
    public static final Item DYNAMITE_X1 = register("dynamite_x1", 4.0f);
    public static final Item DYNAMITE_X5 = register("dynamite_x5", 20.0f);
    public static final Item DYNAMITE_X10 = register("dynamite_x10", 40.0f);

    private static Item register(String name, float power) {
        Identifier id = new Identifier(DynamiteMod.MOD_ID, name);
        DynamiteItem item = new DynamiteItem(new Item.Settings().maxCount(16), power);
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void registerModItems() {
        DynamiteMod.LOGGER.info("Registering dynamite items for " + DynamiteMod.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(DYNAMITE_X1);
            entries.add(DYNAMITE_X5);
            entries.add(DYNAMITE_X10);
        });
    }
}
