package com.example.dynamitemod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

/**
 * A stick of dynamite. Right-click a block to place and detonate it
 * immediately (no fuse) with a configurable blast power.
 */
public class DynamiteItem extends Item {
    private final float power;

    public DynamiteItem(Settings settings, float power) {
        super(settings);
        this.power = power;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos().offset(context.getSide());

        if (!world.isClient) {
            world.createExplosion(
                    context.getPlayer(),
                    pos.getX() + 0.5,
                    pos.getY() + 0.5,
                    pos.getZ() + 0.5,
                    power,
                    Explosion.DestructionType.DESTROY
            );

            PlayerEntity player = context.getPlayer();
            if (player != null && !player.getAbilities().creativeMode) {
                context.getStack().decrement(1);
            }
        }

        return ActionResult.SUCCESS;
    }
}
