package com.gguf.megadynamite.client;

import com.gguf.megadynamite.entity.DynamiteEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class DynamiteEntityRenderer extends EntityRenderer<DynamiteEntity> {

	private static final Identifier TEXTURE = Identifier.of("minecraft", "textures/atlas/blocks.png");
	private final BlockRenderManager blockRenderManager;

	public DynamiteEntityRenderer(EntityRendererFactory.Context context) {
		super(context);
		this.blockRenderManager = context.getBlockRenderManager();
		this.shadowRadius = 0.5f;
	}

	@Override
	public void render(DynamiteEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
		matrices.push();
		matrices.translate(0.0, 0.0, 0.0);
		int fuse = entity.getFuse();
		if (fuse < 20 && fuse / 2 % 2 == 0) {
			float scale = 1.0f - 0.1f * MathHelper.sin((float) fuse * 3.0f);
			matrices.scale(scale, scale, scale);
		}
		matrices.translate(-0.5, 0.0, -0.5);
		this.blockRenderManager.renderBlockAsEntity(entity.getBlockState(), matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
		matrices.pop();
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}

	@Override
	public Identifier getTexture(DynamiteEntity entity) {
		return TEXTURE;
	}
}
