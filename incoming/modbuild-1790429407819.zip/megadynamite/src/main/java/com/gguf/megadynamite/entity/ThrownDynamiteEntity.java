package com.gguf.megadynamite.entity;

import com.gguf.megadynamite.MegaDynamite;
import com.gguf.megadynamite.Special;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

public class ThrownDynamiteEntity extends ThrownItemEntity {

	private static final TrackedData<Integer> COLOR = DataTracker.registerData(ThrownDynamiteEntity.class, TrackedDataHandlerRegistry.INTEGER);

	private float power = 3.0f;
	private Special special = Special.NORMAL;
	private Item sourceItem = MegaDynamite.dynamiteThrowItems[0];

	public ThrownDynamiteEntity(EntityType<? extends ThrownDynamiteEntity> type, World world) {
		super(type, world);
	}

	public ThrownDynamiteEntity(World world, LivingEntity owner, float power, int color, Special special, Item sourceItem) {
		super(MegaDynamite.THROWN_DYNAMITE_ENTITY, owner, world);
		this.power = power;
		this.special = special;
		this.sourceItem = sourceItem;
		this.dataTracker.set(COLOR, color);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		super.initDataTracker(builder);
		builder.add(COLOR, 0xFFFFFF);
	}

	@Override
	protected Item getDefaultItem() {
		return this.sourceItem;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			this.getWorld().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0, 0.02, 0);
		}
	}

	@Override
	protected void onCollision(HitResult hitResult) {
		super.onCollision(hitResult);
		if (!this.getWorld().isClient) {
			if (hitResult instanceof EntityHitResult entityHitResult) {
				entityHitResult.getEntity().damage(this.getDamageSources().thrown(this, this.getOwner()), 1.0f);
			}
			boolean fire = this.special == Special.INCENDIARY || this.special == Special.NUKE;
			this.getWorld().createExplosion(this, this.getX(), this.getY(), this.getZ(), this.power, fire, World.ExplosionSourceType.TNT);

			switch (this.special) {
				case SMOKE -> areaEffect(StatusEffects.NAUSEA, 160, 1);
				case POISON -> areaEffect(StatusEffects.POISON, 120, 1);
				case FROST -> areaEffect(StatusEffects.SLOWNESS, 100, 2);
				case CLUSTER -> {
					for (int i = 0; i < 3; i++) {
						double ox = this.getX() + (this.random.nextDouble() - 0.5) * 5.0;
						double oz = this.getZ() + (this.random.nextDouble() - 0.5) * 5.0;
						this.getWorld().createExplosion(this, ox, this.getY(), oz, Math.max(1.0f, this.power * 0.4f), false, World.ExplosionSourceType.TNT);
					}
				}
				default -> {
				}
			}
			this.discard();
		}
	}

	private void areaEffect(net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, int duration, int amplifier) {
		double radius = 5.0;
		Box box = new Box(this.getX() - radius, this.getY() - radius, this.getZ() - radius, this.getX() + radius, this.getY() + radius, this.getZ() + radius);
		List<LivingEntity> nearby = this.getWorld().getEntitiesByClass(LivingEntity.class, box, LivingEntity::isAlive);
		for (LivingEntity living : nearby) {
			living.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier));
		}
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		this.power = nbt.getFloat("Power");
		int specialIndex = nbt.getInt("Special");
		Special[] values = Special.values();
		this.special = values[Math.max(0, Math.min(values.length - 1, specialIndex))];
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putFloat("Power", this.power);
		nbt.putInt("Special", this.special.ordinal());
	}
}
