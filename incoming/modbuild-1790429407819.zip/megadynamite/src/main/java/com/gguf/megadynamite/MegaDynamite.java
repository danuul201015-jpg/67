package com.gguf.megadynamite;

import com.gguf.megadynamite.block.DynamiteBlock;
import com.gguf.megadynamite.entity.DynamiteEntity;
import com.gguf.megadynamite.entity.ThrownDynamiteEntity;
import com.gguf.megadynamite.item.DynamiteThrowItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

import java.awt.Color;

public class MegaDynamite implements ModInitializer {

	public static final String MOD_ID = "megadynamite";
	public static final int VARIANT_COUNT = 100;

	public static final Block[] dynamiteBlocks = new Block[VARIANT_COUNT];
	public static final Item[] dynamiteThrowItems = new Item[VARIANT_COUNT];

	public static EntityType<DynamiteEntity> DYNAMITE_ENTITY;
	public static EntityType<ThrownDynamiteEntity> THROWN_DYNAMITE_ENTITY;

	public static ItemGroup DYNAMITE_GROUP;

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		DYNAMITE_ENTITY = Registry.register(Registries.ENTITY_TYPE, id("dynamite_primed"),
				EntityType.Builder.<DynamiteEntity>create(DynamiteEntity::new, SpawnGroup.MISC)
						.dimensions(EntityDimensions.fixed(0.98f, 0.98f))
						.maxTrackingRange(10)
						.trackingTickInterval(10)
						.build());

		THROWN_DYNAMITE_ENTITY = Registry.register(Registries.ENTITY_TYPE, id("dynamite_thrown"),
				EntityType.Builder.<ThrownDynamiteEntity>create(ThrownDynamiteEntity::new, SpawnGroup.MISC)
						.dimensions(EntityDimensions.fixed(0.25f, 0.25f))
						.maxTrackingRange(4)
						.trackingTickInterval(10)
						.build());

		for (int i = 1; i <= VARIANT_COUNT; i++) {
			registerVariant(i);
		}

		DYNAMITE_GROUP = Registry.register(Registries.ITEM_GROUP, id("dynamite_group"),
				ItemGroup.create(ItemGroup.Row.TOP, 0)
						.displayName(net.minecraft.text.Text.translatable("itemGroup.megadynamite.dynamite"))
						.icon(() -> new ItemStack(dynamiteBlocks[0]))
						.entries(MegaDynamite::buildGroupEntries)
						.build());
	}

	private static void buildGroupEntries(net.minecraft.item.ItemGroup.DisplayContext context, FabricItemGroupEntries entries) {
		for (Block block : dynamiteBlocks) {
			entries.add(block);
		}
		for (Item item : dynamiteThrowItems) {
			entries.add(item);
		}
	}

	private static void registerVariant(int n) {
		float power = computePower(n);
		int fuseTicks = computeFuse(n);
		int color = computeColor(n);
		Special special = computeSpecial(n);

		String blockId = "dynamite_" + n;
		String throwId = "dynamite_throw_" + n;

		RegistryKey<net.minecraft.loot.LootTable> lootTableKey = RegistryKey.of(RegistryKeys.LOOT_TABLE, id("blocks/" + blockId));

		AbstractBlock.Settings blockSettings = AbstractBlock.Settings.create()
				.mapColor(MapColor.RED)
				.strength(0.0f)
				.sounds(BlockSoundGroup.GRASS)
				.lootTable(lootTableKey);

		DynamiteBlock block = new DynamiteBlock(blockSettings, power, fuseTicks, color, special);
		Registry.register(Registries.BLOCK, id(blockId), block);
		dynamiteBlocks[n - 1] = block;

		BlockItem blockItem = new BlockItem(block, new Item.Settings());
		Registry.register(Registries.ITEM, id(blockId), blockItem);

		DynamiteThrowItem throwItem = new DynamiteThrowItem(new Item.Settings().maxCount(16), power * 0.75f, color, special);
		Registry.register(Registries.ITEM, id(throwId), throwItem);
		dynamiteThrowItems[n - 1] = throwItem;
	}

	private static float computePower(int n) {
		if (n == VARIANT_COUNT) {
			return 24.0f;
		}
		return 1.5f + n * 0.12f;
	}

	private static int computeFuse(int n) {
		return Math.max(10, 90 - n);
	}

	private static int computeColor(int n) {
		float hue = (n - 1) / (float) VARIANT_COUNT;
		return Color.HSBtoRGB(hue, 0.85f, 1.0f) & 0xFFFFFF;
	}

	private static Special computeSpecial(int n) {
		if (n == VARIANT_COUNT) {
			return Special.NUKE;
		}
		Special[] cycle = {Special.NORMAL, Special.INCENDIARY, Special.CLUSTER, Special.SMOKE, Special.FROST, Special.POISON, Special.CHAIN};
		return cycle[(n - 1) % cycle.length];
	}
}
