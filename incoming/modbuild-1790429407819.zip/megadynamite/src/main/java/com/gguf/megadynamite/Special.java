package com.gguf.megadynamite;

/**
 * The "flavor" of a dynamite variant - what happens in addition to the plain
 * explosion. Cycled procedurally across the 100 generated variants so the
 * pack ends up with a lot of different behaviour instead of 100 reskins of
 * the same block.
 */
public enum Special {
	NORMAL,
	INCENDIARY, // sets fire, leaves burning blocks behind
	CLUSTER,    // splits into several smaller explosions around the impact point
	SMOKE,      // huge lingering smoke cloud + Nausea to nearby entities
	FROST,      // freezes nearby water to ice + Slowness to nearby entities
	POISON,     // Poison effect to nearby living entities
	CHAIN,      // also ignites any other MegaDynamite blocks in range
	NUKE        // the big one - reserved for dynamite #100
}
