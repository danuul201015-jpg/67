package com.gguf.megadynamite.entity;

import com.gguf.megadynamite.MegaDynamite;
import com.gguf.megadynamite.Special;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.List;

/**
 * A single shared entity type used by every one of the 100 dynamite blocks.
 * Which block it looks like, how strong it explodes and what happens when it
 * does is all carried per-instance in fields synced through the DataTracker.
 */
public class DynamiteEntity extends Entity {

	private static final TrackedData<Integer> BLOCK_STATE = DataTracker.registerData(DynamiteEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Integer> FUSE = DataTracker.registerData(DynamiteEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Integer> COLOR = DataTracker.registerData(DynamiteEntity.class, TrackedDataHandlerRegistry.INTEGER);

	private float power = 4.0f;
	private Special special = Special.NORMAL;
	private LivingEntity igniter;

	public DynamiteEntity(EntityType<? extends DynamiteEntity> type, World world) {
		super(type, world);
	}

	public DynamiteEntity(World world, double x, double y, double z, BlockState state, float power, int fuseTicks, int color, Special special, LivingEntity igniter) {
		this(MegaDynamite.DYNAMITE_ENTITY, world);
		this.setPosition(x, y, z);
		double angle = this.random.nextDouble() * Math.PI * 2.0;
		this.setVelocity(-Math.sin(angle) * 0.02, 0.2, -Math.cos(angle) * 0.02);
		this.prevX = x;
		this.prevY = y;
		this.prevZ = z;
		this.power = power;
		this.special = special;
		this.igniter = igniter;
		this.dataTracker.set(BLOCK_STATE, Block.getRawIdFromState(state));
		this.dataTracker.set(FUSE, fuseTicks);
		this.dataTracker.set(COLOR, color);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(BLOCK_STATE, Block.getRawIdFromState(MegaDynamite.dynamiteBlocks[0].getDefaultState()));
		builder.add(FUSE, 80);
		builder.add(COLOR, 0xFFFFFF);
	}

	public BlockState getBlockState() {
		return Block.getStateFromRawId(this.dataTracker.get(BLOCK_STATE));
	}

	public int getFuse() {
		return this.dataTracker.get(FUSE);
	}

	public int getColor() {
		return this.dataTracker.get(COLOR);
	}

	@Override
	public void tick() {
		if (!this.isAlive()) {
			return;
		}
		this.prevX = this.getX();
		this.prevY = this.getY();
		this.prevZ = this.getZ();
		this.setVelocity(this.getVelocity().multiply(0.98, 0.96, 0.98));
		if (this.isOnGround()) {
			this.setVelocity(this.getVelocity().multiply(0.7, -0.5, 0.7));
		}
		this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());

		if (this.getWorld().isClient) {
			int color = this.getColor();
			float r = ((color >> 16) & 0xFF) / 255f;
			float g = ((color >> 8) & 0xFF) / 255f;
			float b = (color & 0xFF) / 255f;
			this.getWorld().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.5, this.getZ(), 0, 0.05, 0);
			this.getWorld().addParticle(new DustParticleEffect(new Vector3f(r, g, b), 1.3f), this.getX(), this.getY() + 0.6, this.getZ(), 0, 0, 0);
		} else {
			int fuse = this.getFuse() - 1;
			this.dataTracker.set(FUSE, fuse);
			if (fuse <= 0) {
				this.discard();
				this.explode();
			}
		}
	}

	private void explode() {
		World world = this.getWorld();
		if (world.isClient) {
			return;
		}
		float finalPower = this.power;
		boolean fire = this.special == Special.INCENDIARY || this.special == Special.NUKE;

		world.createExplosion(this, this.getX(), this.getY(), this.getZ(), finalPower, fire, World.ExplosionSourceType.TNT);

		switch (this.special) {
			case CLUSTER -> spawnClusterBursts(world);
			case SMOKE -> applyAreaEffect(world, StatusEffects.NAUSEA, 200, 1, 6.0);
			case FROST -> applyAreaEffect(world, StatusEffects.SLOWNESS, 100, 2, 6.0);
			case POISON -> applyAreaEffect(world, StatusEffects.POISON, 140, 1, 6.0);
			case CHAIN -> chainNearbyDynamite(world);
			case NUKE -> {
				applyAreaEffect(world, StatusEffects.NAUSEA, 100, 0, 10.0);
				world.createExplosion(this, this.getX(), this.getY(), this.getZ(), finalPower * 0.5f, true, World.ExplosionSourceType.TNT);
			}
			default -> {
			}
		}
	}

	private void spawnClusterBursts(World world) {
		if (!(world instanceof ServerWorld)) {
			return;
		}
		for (int i = 0; i < 4; i++) {
			double ox = this.getX() + (this.random.nextDouble() - 0.5) * 6.0;
			double oy = this.getY() + this.random.nextDouble() * 2.0;
			double oz = this.getZ() + (this.random.nextDouble() - 0.5) * 6.0;
			world.createExplosion(this, ox, oy, oz, Math.max(1.0f, this.power * 0.4f), false, World.ExplosionSourceType.TNT);
		}
	}

	private void applyAreaEffect(World world, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, int durationTicks, int amplifier, double radius) {
		Box box = new Box(this.getX() - radius, this.getY() - radius, this.getZ() - radius, this.getX() + radius, this.getY() + radius, this.getZ() + radius);
		List<LivingEntity> nearby = world.getEntitiesByClass(LivingEntity.class, box, LivingEntity::isAlive);
		for (LivingEntity living : nearby) {
			living.addStatusEffect(new StatusEffectInstance(effect, durationTicks, amplifier));
		}
	}

	private void chainNearbyDynamite(World world) {
		BlockPos center = this.getBlockPos();
		int radius = 3;
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dy = -radius; dy <= radius; dy++) {
				for (int dz = -radius; dz <= radius; dz++) {
					BlockPos pos = center.add(dx, dy, dz);
					BlockState state = world.getBlockState(pos);
					if (state.getBlock() instanceof com.gguf.megadynamite.block.DynamiteBlock dynamiteBlock) {
						world.removeBlock(pos, false);
						dynamiteBlock.primeAt(world, pos, this.igniter);
					}
				}
			}
		}
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		this.power = nbt.getFloat("Power");
		this.dataTracker.set(FUSE, nbt.getInt("Fuse"));
		this.dataTracker.set(COLOR, nbt.getInt("Color"));
		int specialIndex = nbt.getInt("Special");
		Special[] values = Special.values();
		this.special = values[Math.max(0, Math.min(values.length - 1, specialIndex))];
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putFloat("Power", this.power);
		nbt.putInt("Fuse", this.getFuse());
		nbt.putInt("Color", this.getColor());
		nbt.putInt("Special", this.special.ordinal());
	}

	@Override
	public boolean shouldRender(double distance) {
		return true;
	}

	@Override
	public boolean isOnFire() {
		return false;
	}
}
