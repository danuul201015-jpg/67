package com.gguf.megadynamite.block;

import com.gguf.megadynamite.Special;
import com.gguf.megadynamite.entity.DynamiteEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * One of the 100 dynamite variants. Behaves like vanilla TNT (ignite with
 * flint & steel, fire, or redstone) but its explosion power, fuse length,
 * particle color and "special" behaviour are configurable per instance -
 * see {@link com.gguf.megadynamite.MegaDynamite} for how the 100 variants
 * are generated.
 */
public class DynamiteBlock extends Block {

	private final float power;
	private final int fuseTicks;
	private final int color;
	private final Special special;

	public DynamiteBlock(Settings settings, float power, int fuseTicks, int color, Special special) {
		super(settings);
		this.power = power;
		this.fuseTicks = fuseTicks;
		this.color = color;
		this.special = special;
	}

	public float getPower() {
		return power;
	}

	public int getColor() {
		return color;
	}

	public Special getSpecial() {
		return special;
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		if (!oldState.isOf(state.getBlock()) && world.isReceivingRedstonePower(pos)) {
			igniteAndRemove(world, pos, null);
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
		if (world.isReceivingRedstonePower(pos)) {
			igniteAndRemove(world, pos, null);
		}
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, net.minecraft.entity.player.PlayerEntity player, BlockHitResult hit) {
		ItemStack stack = player.getStackInHand(Hand.MAIN_HAND);
		if (stack.getItem() instanceof FlintAndSteelItem) {
			igniteAndRemove(world, pos, player);
			if (!player.getAbilities().creativeMode) {
				stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
			}
			world.playSound(null, pos, SoundEvents.ITEM_FLINTANDSTEEL_USE, SoundCategory.BLOCKS, 1.0f, world.getRandom().nextFloat() * 0.4f + 0.8f);
			return ActionResult.SUCCESS;
		}
		return ActionResult.PASS;
	}

	@Override
	protected void onProjectileHit(World world, BlockState state, BlockHitResult hit, ProjectileEntity projectile) {
		if (!world.isClient && projectile.isOnFire()) {
			igniteAndRemove(world, hit.getBlockPos(), projectile.getOwner() instanceof LivingEntity living ? living : null);
		}
	}

	private void igniteAndRemove(World world, BlockPos pos, LivingEntity igniter) {
		if (world.isClient) {
			return;
		}
		world.removeBlock(pos, false);
		primeAt(world, pos, igniter);
	}

	/** Used by DynamiteEntity's CHAIN special to ignite neighbours. */
	public void primeAt(World world, BlockPos pos, LivingEntity igniter) {
		DynamiteEntity entity = new DynamiteEntity(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5,
				this.getDefaultState(), this.power, this.fuseTicks, this.color, this.special, igniter);
		world.spawnEntity(entity);
		world.playSound(null, pos, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0f, 1.0f);
	}
}
