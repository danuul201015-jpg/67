package com.gguf.megadynamite.item;

import com.gguf.megadynamite.Special;
import com.gguf.megadynamite.entity.ThrownDynamiteEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class DynamiteThrowItem extends Item {

	private final float power;
	private final int color;
	private final Special special;

	public DynamiteThrowItem(Settings settings, float power, int color, Special special) {
		super(settings);
		this.power = power;
		this.color = color;
		this.special = special;
	}

	public int getColor() {
		return color;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_ENDER_PEARL_THROW, SoundCategory.NEUTRAL, 0.5f, 0.4f / (world.getRandom().nextFloat() * 0.4f + 0.8f));

		if (!world.isClient) {
			ThrownDynamiteEntity entity = new ThrownDynamiteEntity(world, user, this.power, this.color, this.special, this);
			entity.setItem(stack);
			entity.setVelocity(user, user.getPitch(), user.getYaw(), 0.0f, 1.5f, 1.0f);
			world.spawnEntity(entity);
		}

		user.incrementStat(net.minecraft.stat.Stats.USED.getOrCreateStat(this));
		if (!user.getAbilities().creativeMode) {
			stack.decrement(1);
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
