package com.gguf.megadynamite.client;

import com.gguf.megadynamite.MegaDynamite;
import com.gguf.megadynamite.block.DynamiteBlock;
import com.gguf.megadynamite.item.DynamiteThrowItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.block.Block;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.item.Item;

public class MegaDynamiteClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(MegaDynamite.DYNAMITE_ENTITY, DynamiteEntityRenderer::new);
		EntityRendererRegistry.register(MegaDynamite.THROWN_DYNAMITE_ENTITY, context -> new FlyingItemEntityRenderer<>(context, 1.0f, false));

		ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
			if (state.getBlock() instanceof DynamiteBlock dynamiteBlock) {
				return dynamiteBlock.getColor();
			}
			return 0xFFFFFF;
		}, MegaDynamite.dynamiteBlocks);

		ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
			if (stack.getItem() instanceof net.minecraft.item.BlockItem blockItem && blockItem.getBlock() instanceof DynamiteBlock dynamiteBlock) {
				return dynamiteBlock.getColor();
			}
			return 0xFFFFFF;
		}, MegaDynamite.dynamiteBlocks);

		ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
			if (stack.getItem() instanceof DynamiteThrowItem throwItem) {
				return throwItem.getColor();
			}
			return 0xFFFFFF;
		}, MegaDynamite.dynamiteThrowItems);
	}
}
